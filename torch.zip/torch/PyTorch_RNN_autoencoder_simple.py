# -*- coding: utf-8 -*-
"""
Created on Wed May 13 09:28:36 2020

@author: tsato
"""

# -*- coding: utf-8 -*-

import urllib

import math

import torch
import torch.nn as nn
import torch.optim as optimizers
from torch.utils.data import DataLoader
from torch.utils.data import random_split
from torchvision import datasets
import torchvision.transforms as transforms


import os
import copy
import subprocess
import re
import numpy as np
from sklearn.model_selection import train_test_split
import matplotlib
#matplotlib.use("Agg")
import matplotlib.pyplot as plt




#===========================================================
# PyTorchのDNNクラス
# ------------------------------------
#
#===========================================================
class DNN(nn.Module):
    #============================================
    # ● 初期化
    #============================================   
    def __init__(self, input_dim, hidden_dim, time_length, output_dim):
        super().__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.time_length = time_length
        self.output_dim = output_dim
        #
        self.encoder = nn.LSTM(self.input_dim, self.hidden_dim, batch_first=True)
        self.decode1 = nn.LSTM(self.hidden_dim, self.hidden_dim, batch_first=True)
        self.decode2 = nn.LSTM(self.hidden_dim, self.output_dim, batch_first=True)
        
        #初期化
        nn.init.xavier_normal_(self.encoder.weight_ih_l0)
        nn.init.orthogonal_(self.encoder.weight_hh_l0)
        nn.init.xavier_normal_(self.decode1.weight_ih_l0)
        nn.init.orthogonal_(self.decode1.weight_hh_l0)
        nn.init.xavier_normal_(self.decode2.weight_ih_l0)
        nn.init.orthogonal_(self.decode2.weight_hh_l0)
    #end
    #============================================
    # ● 順伝搬
    #============================================   
    def forward(self, x):
        #input = torch.randn(64, 22, 98)   
        #print("DNN input")
        #print(x)
        encoded, fin_encode = self.encoder(x)
        #print(encoded)
        #最後の特徴量を、時系列長の分コピー
        #print(self.time_length)
        decoder_input = fin_encode[0].repeat(1, self.time_length, 1)#encoded#
        #print(decoder_input)
        #デコーダへ
        decoded1, fin_dec = self.decode1(decoder_input)
        #print(decoded1)
        #print(";;;;")
        decoded2, _ = self.decode2(decoded1)
        #print(decoded2)
        #rint("fin...")
        return decoded2
    #end
#end


#============================================
# ● 画像とターゲットラベル読み取り
#============================================    
def make_learning_data():
    x1 = [[1,2,3,4,5], [10,20,30,40,50]]
    x1np = np.asarray(x1).transpose()
    print(x1np)
    X = []
    X.append(x1np)
    X.append(x1np)
    X = np.asarray(X)
    #X = X.transpose()    
    print("--------")
    print(X)
    Y = copy.deepcopy(X)
    return X, Y
#end


#============================================
# ● 損失関数
#============================================        
def compute_loss(y, t):
    return criterion(y, t)
#end
    
#============================================
# ● １回の学習処理
#============================================        
def train_step(model, optimizer, x, t):
    model.train()
    preds = model(x)
    loss = compute_loss(preds, t)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    return loss, preds
#end
    
#============================================
# ● １回の評価処理
#============================================        
def val_step(model, x, t):
    model.eval()
    preds = model(x)
    loss = compute_loss(preds, t)
    return loss, preds
#end  
    
    
#============================================
# ● 画像とターゲットラベル読み取り
#============================================    
def make_learning_data():
    x1 = [[1,2,3,4,5], [10,20,30,40,50]]
    x1np = np.asarray(x1).transpose()
    print(x1np)
    X = []
    X.append(x1np)
    X.append(x1np)
    X = np.asarray(X)
    #X = X.transpose()    
    print("--------")
    print(X)
    Y = copy.deepcopy(X)
    return X, Y
#end
    
#============================================
# ● メイン関数
#============================================   
if __name__ == '__main__':
    #乱数初期化
    seed = 1213465    
    np.random.seed(seed)
    torch.manual_seed(seed)
    #cuda有無
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    #
    #データ作成
    root = os.path.join('~', '.torch', 'mnist')
    transform = transforms.Compose([transforms.ToTensor(), lambda x: x.view(-1)])
    mnist_train = datasets.MNIST(root=root, download=True, train=True, transform=transform)
    mnist_test = datasets.MNIST(root=root, download=True,  train=False, transform=transform)
    
    #
    #データ作成    
    X, Y = make_learning_data()
    #np.savetxt(fname="test.csv", X=Y, delimiter=",")

    X = X.astype('float32')
    X = X / 255.0

    X_train, X_test, y_train1, y_test1 = train_test_split(X, Y, test_size=0.5, random_state=111)
    y_train = X_train
    y_test = X_test
    #
    #ネットワーク構築
    model = DNN(2, 10, 5, 2).to(device)
    
    batch_size = 1
    
    print(X_train)
    
    #損失関数
    criterion = nn.MSELoss()
    #optimizer定義
    optimizer = optimizers.Adam(model.parameters(), lr=0.1, betas=(0.9, 0.999), amsgrad=True)

    #エポック数
    epochs = 500
    hist = {'loss': [], 'accuracy': [], 'val_loss': [], 'val_accuracy': []}   
    
    is_train = True
    #   
    if(is_train):
        #エポックループ
        for epoch in range(epochs):
            train_loss = 0.
            train_acc = 0.
            val_loss = 0.
            val_acc = 0.
    
            #１つのデータごとの学習
            x = torch.Tensor([X_train[0]])
            x = x.to(device)
            loss, preds = train_step(model, optimizer, x, x)
            train_loss += loss.item()
            train_loss += loss.item()
            
            #評価
            x = torch.Tensor([X_train[0]])
            x = x.to(device)            
            loss, preds = train_step(model, optimizer, x, x)
            val_loss += loss.item()
            train_loss += loss.item()
    
            hist['loss'].append(train_loss)
            hist['accuracy'].append(train_acc)
            hist['val_loss'].append(val_loss)
            hist['val_accuracy'].append(val_acc)
    
            print('epoch: {}, loss: {:.3}, acc: {:.3f}'
                  ', val_loss: {:.3}, val_acc: {:.3f}'.format(
                      epoch+1,
                      train_loss,
                      train_acc,
                      val_loss,
                      val_acc
                  ))
            #if es(val_loss):
            #    break
        #
        #モデルの評価    
        # 検証データの誤差の可視化
        loss = hist['loss']
        val_loss = hist['val_loss']
        fig = plt.figure()
        plt.rc('font', family='serif')
        plt.plot(range(len(loss)), loss, color='gray', linewidth=1, label='loss')
        plt.plot(range(len(val_loss)), val_loss, color='black', linewidth=1,  label='val_loss')
        plt.xlabel('epochs')
        plt.ylabel('loss')
        plt.legend()
        # plt.savefig('output.jpg')
        plt.show()
    
        #
        #モデルを保存
        torch.save(model.state_dict(), "modeltorch.h5")
    #
    #学習結果を読み取る
    else:
        model.load_state_dict(torch.load("modeltorch.h5"))
    #end
        
    
    #
    # テストデータの評価
    test_loss = 0.0
    test_acc = 0.0
    x = torch.Tensor([X_train[0]])
    x = x.to(device)            
    loss, preds = train_step(model, optimizer, x, x)
    print("inputs")
    print(X_train*255)
    print("Fin preds")
    print(preds*255)
    test_loss += loss.item()
    test_loss += loss.item()
    print('test_loss: {:.3f}, test_acc: {:.3f}'.format(
        test_loss,
        test_acc
    ))
#end
    
    

