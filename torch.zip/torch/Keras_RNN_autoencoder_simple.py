# -*- coding: utf-8 -*-
"""
Created on Wed May 13 09:28:36 2020

@author: tsato
"""

# -*- coding: utf-8 -*-

import urllib

import math

import tensorflow as tf
import tensorflow.keras
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Input, Dense, LSTM
from tensorflow.keras.layers import RepeatVector, concatenate
from tensorflow.keras.activations import relu, softmax

from tensorflow.keras.models import load_model
from tensorflow.keras import optimizers


import os
import copy
import subprocess
import re
import numpy as np
from sklearn.model_selection import train_test_split
import matplotlib
#matplotlib.use("Agg")
import matplotlib.pyplot as plt


#============================================
# ● 画像とターゲットラベル読み取り
#============================================    
def make_learning_data():
    x1 = [[1,2,3,4,5], [10,20,30,40,50]]
    x1np = np.asarray(x1).transpose()
    print(x1np)
    X = []
    X.append(x1np)
    X.append(x1np)
    X = np.asarray(X)
    #X = X.transpose()    
    print("--------")
    print(X)
    Y = copy.deepcopy(X)
    return X, Y
#end

if __name__ == "__main__":
    #データ作成    
    X, Y = make_learning_data()
    #np.savetxt(fname="test.csv", X=Y, delimiter=",")

    X = X.astype('float32')
    X = X / 255.0

    X_train, X_test, y_train1, y_test1 = train_test_split(X, Y, test_size=0.5, random_state=111)
    y_train = X_train
    y_test = X_test
    
    print(X_train)
    

 #   model.save_weights(os.path.join(result_dir, 'finetuning.h5'))
 #   save_history(history, os.path.join(result_dir, 'history_finetuning.txt'))

    time_length = 5
    input_num = 2
    latent_dim = 10
    
    inputs = Input(shape=(time_length, input_num))
    encoded = LSTM(latent_dim, activation="tanh", recurrent_activation="sigmoid", return_sequences=False)(inputs)
    ##return_sequence: TrueにしてRNNレイヤーの毎時刻の出力を得るか、Falseにして最後の時刻のみの出力を得る
    
    #decode
    hidden = RepeatVector(time_length)(encoded)
    decoded1 = LSTM(latent_dim, activation="tanh", recurrent_activation="sigmoid", return_sequences=True)(hidden)
    decoded2 = LSTM(input_num, activation="tanh", recurrent_activation="sigmoid", return_sequences=True)(decoded1)
    ##return_sequence: TrueにしてRNNレイヤーの毎時刻の出力を得る
    
    total_input = inputs
    model = Model(inputs=total_input, outputs=decoded2)
    model.summary()
    # コンパイル
    adm = tensorflow.keras.optimizers.Adam(lr=1.0e-2, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)

    model.compile(optimizer=adm, loss='mean_squared_error')
    X_train_rev = X_train[:,::-1,:]
    X_test_rev = X_test[:,::-1,:]
    print(X_train)
    print(X_train_rev)
    #exit(1)
    
    #学習
    history = model.fit([X_train, X_train_rev], X_train, epochs=500, batch_size=1, 
                    validation_data=([X_test, X_test_rev], X_train), verbose = 2, shuffle=True)
     
    
    model.save('model.h5', include_optimizer=True)

    scores = model.evaluate([X_train, X_train_rev], X_train, verbose=2)
    #
    #print(history.history)
    np.savetxt("histry_data_loss.csv", X=history.history['loss'], delimiter=',')
    
    
    #予測
    predict = model.predict([X_train])
    print(predict*255)
    print( np.linalg.norm(predict[0]-X_train[0]) )
    
    X2 = X_train + 10
    #Y = [[[1,2,3,4,5]], [[1,2,3,4,5]]]    
    predict = model.predict([X2])
    print(predict*255)
    print( np.linalg.norm(predict[0]-X2[0]) )
    

#end
